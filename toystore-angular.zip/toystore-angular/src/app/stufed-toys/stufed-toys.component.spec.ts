import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StufedToysComponent } from './stufed-toys.component';

describe('StufedToysComponent', () => {
  let component: StufedToysComponent;
  let fixture: ComponentFixture<StufedToysComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StufedToysComponent]
    });
    fixture = TestBed.createComponent(StufedToysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
