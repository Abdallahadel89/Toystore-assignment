import { Component } from '@angular/core';

@Component({
  selector: 'app-stufed-toys',
  templateUrl: './stufed-toys.component.html',
  styleUrls: ['./stufed-toys.component.css']
})
export class StufedToysComponent {

}
