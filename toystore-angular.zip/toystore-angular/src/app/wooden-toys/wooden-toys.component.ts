import { Component } from '@angular/core';

@Component({
  selector: 'app-wooden-toys',
  templateUrl: './wooden-toys.component.html',
  styleUrls: ['./wooden-toys.component.css']
})
export class WoodenToysComponent {

}
