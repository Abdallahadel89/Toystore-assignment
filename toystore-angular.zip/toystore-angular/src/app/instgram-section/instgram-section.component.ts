import { Component } from '@angular/core';

@Component({
  selector: 'app-instgram-section',
  templateUrl: './instgram-section.component.html',
  styleUrls: ['./instgram-section.component.css']
})
export class InstgramSectionComponent {

}
