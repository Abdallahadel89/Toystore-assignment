import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InstgramSectionComponent } from './instgram-section.component';

describe('InstgramSectionComponent', () => {
  let component: InstgramSectionComponent;
  let fixture: ComponentFixture<InstgramSectionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [InstgramSectionComponent]
    });
    fixture = TestBed.createComponent(InstgramSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
